Full package including Colab notebooks to train detector and workflow to download models from HuggingFace before build.
